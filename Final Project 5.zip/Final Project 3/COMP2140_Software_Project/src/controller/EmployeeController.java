package controller;

import entities.*;

public class EmployeeController {
    public EmployeeController() {

    }

    public static void storeEmployee(String name, String role, String gender, int ID, String passwordsString) {
        Employee employee = new Employee(name, role, gender, ID, passwordsString);
        EDController.store_to_employee_details(employee);
    }

    public static void checkLogin(String id, String password, boolean flag) {
        EDController.login(id, password, flag);
    }
}