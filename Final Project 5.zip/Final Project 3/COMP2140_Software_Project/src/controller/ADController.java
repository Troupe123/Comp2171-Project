package controller;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;
import entities.*;

public class ADController {

    public ADController() {
    }

    public static void store_to_artifact_database(Artifact artifact) throws IOException {
        String text;

        // creates a file named stud_records.txt
        File file = new File("artifact_catalogue.txt");

        // needed in order to handle appending data to file if file already exists:
        FileWriter fileWriter = new FileWriter(file, file.exists());
        BufferedWriter output = new BufferedWriter(fileWriter);

        // determining which button is selected for gender:
        text = artifact.getName().trim() + " " + artifact.getID() + " " + artifact.getDescription().trim() + " "
                + artifact.getStatus() + " "
                + artifact.getWeight() + " " + artifact.getPrice() + " " + artifact.getArrivalDate().trim();

        output.write(text);

        // adding new line for next record to be appended:
        if (file.exists())
            output.newLine();

        try {
            output.close();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        try {
            fileWriter.close();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        if (file.exists())
            System.out.println("Text has been appended to the file: artifact_catalogue.txt");
        else
            System.out.println("Text has been written to a new file: artifact_catalogue.txt");
        // note this does not display on the GUI but the terminal:

    }

    public static void remove_from_database(ArrayList<Artifact> alist, String id) {
        String text_;
        for (int i = 0; i < alist.size(); i++) {
            if (alist.get(i).getID() == Integer.parseInt(id)) {
                System.out.println("The Artifact has been removed");
                alist.remove(i);
                try {
                    File file = new File("artifact_catalogue.txt");
                    file.delete(); // deletes the existing file
                    File file_ = new File("artifact_catalogue.txt"); // recreates it to be filled with the updated
                                                                     // information

                    FileWriter fileWriter = new FileWriter(file, file_.exists());
                    BufferedWriter output = new BufferedWriter(fileWriter);

                    for (Artifact a : alist) {
                        text_ = a.getName() + " " + a.getID() + " " + a.getDescription() + " " + a.getStatus() + " "
                                + a.getWeight() +
                                " " + a.getPrice() + " " + a.getArrivalDate();
                        output.write(text_); // each record is written to the file
                        if (file_.exists())
                            output.newLine();
                    }

                    output.close();
                    fileWriter.close();
                } catch (NumberFormatException nfe) {
                    System.out.println("Incorrect input format. Please to enter a number.");
                } catch (IOException ioe) {
                }
            }
        }
    }

    public static ArrayList<Artifact> retrieveArtifacts(String sfile, String search) {
        Scanner pscan = null;
        ArrayList<Artifact> alist = new ArrayList<Artifact>();
        try {
            // takes a file name as paramter and reads information from it
            pscan = new Scanner(new File(sfile));
            while (pscan.hasNext()) {
                String[] nextLine = pscan.nextLine().split(" ");
                if (search.split(" ").length == 1) {
                    for (int x = 0; x < nextLine.length; x++) {
                        if (search.equals(nextLine[x])) {
                            String name = nextLine[0];
                            int Id = Integer.parseInt(nextLine[1]); // converts the id number to an integer
                            String description = nextLine[2]; //
                            String status = nextLine[3];
                            double weight = Double.parseDouble(nextLine[4]);
                            double price = Double.parseDouble(nextLine[5]);
                            String date_arrival = nextLine[6];
                            alist.add(new Artifact(name, Id, description, status, weight, price, date_arrival));
                            System.out.println(alist);
                        }
                    }
                }
                if (search.split(" ").length == 3) {
                    String[] message = search.split(" ");

                    boolean part1 = Arrays.asList(nextLine).contains(message[0]);
                    boolean part2 = Arrays.asList(nextLine).contains(message[2]);

                    if ((message[1].equals("AND") && part1 && part2) ||
                            (message[1].equals("OR") && (part1 || part2)) ||
                            (message[1].equals("NOT") && part1 && !part2)) {
                        String name = nextLine[0];
                        int Id = Integer.parseInt(nextLine[1]); // converts the id number to an integer
                        String description = nextLine[2]; //
                        String status = nextLine[3];
                        double weight = Double.parseDouble(nextLine[4]);
                        double price = Double.parseDouble(nextLine[5]);
                        String date_arrival = nextLine[6];
                        alist.add(new Artifact(name, Id, description, status, weight, price, date_arrival));
                        System.out.println(alist);
                    }

                }
            }
            pscan.close();
        } catch (IOException e) {
        }
        return alist;
    }

    public static ArrayList<Artifact> retrieveArtifacts2(String sfile) {
        Scanner pscan = null;
        ArrayList<Artifact> alist = new ArrayList<Artifact>();
        try {
            // takes a file name as paramter and reads information from it
            pscan = new Scanner(new File(sfile));
            while (pscan.hasNext()) {
                String[] nextLine = pscan.nextLine().split(" ");
                String name = nextLine[0];
                int Id = Integer.parseInt(nextLine[1]); // converts the id number to an integer
                String description = nextLine[2]; //
                String status = nextLine[3];
                double weight = Double.parseDouble(nextLine[4]);
                double price = Double.parseDouble(nextLine[5]);
                String date_arrival = nextLine[6];
                alist.add(new Artifact(name, Id, description, status, weight, price, date_arrival));
            }
            pscan.close();
        } catch (IOException e) {
        }
        return alist;
    }

}
