package controller;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import entities.*;
//import java.nio.charset.Charset;
//import java.security.MessageDigest;

//import java.nio.charset.StandardCharsets;

//import java.security.NoSuchAlgorithmException;

import javax.swing.JOptionPane;

import Menus.EmployeeMenu;
import Menus.ManagerMenu;
import Security.SecurePassword;

public class EDController {
    // private static final String HASH_ALGORITHM = "SHA-256";
    // private static final char[] HEX_ARRAY = "0123456789ABCDEF".toCharArray();

    public EDController() {

    }

    public static void store_to_employee_details(Employee employee) {
        if (!employee.getName().isEmpty() && employee.getpassword().length() > 0
                && (!Integer.toString(employee.getID()).isEmpty())) {
            String name_ = employee.getName().trim();
            String role_ = employee.getRole().trim();
            int Id = employee.getID();
            String password = new String(employee.getpassword());
            String gender = employee.getGender();
            byte[] userHash = SecurePassword.hashPassword(password);
            String userHashHex = SecurePassword.bytesToHex(userHash);
            try {
                // Creates a file named admin.txt
                File file = new File("employee_details.txt");

                // Create a FileWriter object to write to the file:
                FileWriter fileWriter = new FileWriter(file, file.exists());

                // Create a BufferedWriter object to write text to the FileWriter
                BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);

                // Handles writing name in format: first_last
                String[] names = name_.split(" ");

                // Gets username and computed hashed password and stores in String text
                String text = names[0] + "_" + names[1] + " " + role_ + " " + gender + " " + Id + " "
                        + userHashHex;

                // Write the text to the file
                bufferedWriter.write(text);

                if (file.exists())
                    bufferedWriter.newLine();

                // Close the BufferedWriter and FileWriter
                bufferedWriter.close();
                fileWriter.close();

                JOptionPane.showMessageDialog(null, "Addition successful!");
            } catch (IOException IOE) {
            }
        }
        // error message for null input:
        else
            JOptionPane.showMessageDialog(null, "Null input detected. Please enter valid characters.");
    }

    public static void login(String id, String password_, boolean manager_flag) {
        int Id = Integer.parseInt(id);
        String password = new String(password_);
        byte[] userHash = SecurePassword.hashPassword(password);
        String userHashHex = SecurePassword.bytesToHex(userHash);
        int flag = -1;
        String line;
        try {
            // Create a File object with the given file name:
            File file = new File("employee_details.txt");

            // Check if the file exists:
            if (!file.exists())
                JOptionPane.showMessageDialog(null,
                        "No user account has been created yet. Please create a user");

            // Create a FileReader object to read from the file:
            FileReader fileReader = new FileReader(file);

            // Create a BufferedReader object to read text from the FileReader:
            BufferedReader bufferedReader = new BufferedReader(fileReader);

            // loops through file
            while ((line = bufferedReader.readLine()) != null) {
                String[] login = line.split(" ");
                int check = Integer.parseInt(login[3]);
                // Compares fields from text to fields from JText & PasswordFields:
                if (login[1].equals("Manager") && check == Id && login[4].equals(userHashHex)) {
                    manager_flag = true;
                    JOptionPane.showMessageDialog(null, "User with ID#: [" + login[3] + "] logged in");
                    new ManagerMenu(manager_flag);
                    // System.out.println("SUCCESSFUL MANAGER");
                    bufferedReader.close();
                    flag = 0;

                }
                if (login[1].equals("Entry_Level_Employee") && check == Id
                        && login[4].equals(userHashHex)) {
                    manager_flag = false;
                    JOptionPane.showMessageDialog(null, "User with ID#: [" + login[3] + "] logged in");
                    new EmployeeMenu(manager_flag);
                    // System.out.println("SUCCESSFUL EMPLOYEE");

                    bufferedReader.close();
                    flag = 0;

                }
            }
            // handles case where uname or pwd is wrong:
            if (flag == -1)
                JOptionPane.showMessageDialog(null, "Incorrect username or password. Please try again!");
            bufferedReader.close();
            fileReader.close();
        } catch (IOException IOE) {
        }

    }

}
