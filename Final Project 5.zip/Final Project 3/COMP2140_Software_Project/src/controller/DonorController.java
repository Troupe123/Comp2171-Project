package controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import entities.*;

public class DonorController {

    public DonorController() {

    }

    public static void storeDonor(String name, int ID, String contact, String ArtifactsDonated, int numArtifacts)
            throws IOException {
        DDController.AddDonor(name, ID, contact, ArtifactsDonated, numArtifacts);
    }

    public static void remove(ArrayList<Donor> dlist, String id) throws IOException {
        DDController.remove_donor(dlist, id);
    }

    public static ArrayList<Donor> loadDonors(String dfile) {
        return DDController.load_donor_details(dfile);

    }

    public static class nameCompare implements Comparator<Donor> {
        public int compare(Donor d1, Donor d2) {
            return d1.getName().compareTo(d2.getName());
        }
    }

    public static class sortNumArtifacts implements Comparator<Donor> {
        public int compare(Donor d1, Donor d2) {
            // this function sorts in ascending order
            if (d1.getNumArtifacts() > d2.getNumArtifacts())
                return 1;

            if (d1.getNumArtifacts() < d2.getNumArtifacts())
                return -1;

            return 0;

        }
    }

}
