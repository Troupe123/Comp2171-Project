package controller;

import entities.Artifact;

import java.util.ArrayList;
import java.util.Comparator;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ArtifactController {

    public ArtifactController() {

    }

    public static void storeArtifact(String name, int ID, String Description, String status, double weight,
            double price,
            String arrivalDate) throws IOException {
        Artifact artifact = new Artifact(name, ID, Description, status, weight, price, arrivalDate);
        ADController.store_to_artifact_database(artifact);

    }

    public static void remove(ArrayList<Artifact> alist, String id) throws IOException {
        ADController.remove_from_database(alist, id);
    }

    public static ArrayList<Artifact> loadArtifacts(String sfile) {
        return ADController.retrieveArtifacts2(sfile);

    }

    public static ArrayList<Artifact> Filter1(ArrayList<Artifact> alist) {
        ArrayList<Artifact> filteredList = new ArrayList<>();
        for (int x = 0; x < alist.size(); x++) {

            if (alist.get(x).getWeight() >= 0.00 && alist.get(x).getWeight() <= 20.00) {
                filteredList.add(alist.get(x));
            }

        }
        return filteredList;
    }

    public static ArrayList<Artifact> Filter2(ArrayList<Artifact> alist) {
        ArrayList<Artifact> filteredList = new ArrayList<>();
        for (int x = 0; x < alist.size(); x++) {
            if (alist.get(x).getWeight() >= 20.00 && alist.get(x).getWeight() <= 100.00) {
                filteredList.add(alist.get(x));
            }

        }
        return filteredList;
    }

    public static ArrayList<Artifact> Filter3(ArrayList<Artifact> alist) {
        ArrayList<Artifact> filteredList = new ArrayList<>();
        for (int x = 0; x < alist.size(); x++) {
            if (alist.get(x).getWeight() > 100) {
                filteredList.add(alist.get(x));
            }

        }
        return filteredList;
    }

    public static ArrayList<Artifact> Price1(ArrayList<Artifact> alist) {
        ArrayList<Artifact> filteredList = new ArrayList<>();
        for (int x = 0; x < alist.size(); x++) {

            if (alist.get(x).getPrice() >= 0.00 && alist.get(x).getPrice() <= 100000.00) {
                filteredList.add(alist.get(x));
            }

        }
        return filteredList;

    }

    public static ArrayList<Artifact> Price2(ArrayList<Artifact> alist) {
        ArrayList<Artifact> filteredList = new ArrayList<>();
        for (int x = 0; x < alist.size(); x++) {

            if (alist.get(x).getPrice() > 100000.00 && alist.get(x).getPrice() <= 1000000.00) {
                filteredList.add(alist.get(x));
            }

        }
        return filteredList;

    }

    public static ArrayList<Artifact> Price3(ArrayList<Artifact> alist) {
        ArrayList<Artifact> filteredList = new ArrayList<>();
        for (int x = 0; x < alist.size(); x++) {

            if (alist.get(x).getPrice() > 1000000.00) {
                filteredList.add(alist.get(x));
            }

        }
        return filteredList;

    }

    public static class nameCompare implements Comparator<Artifact> {
        public int compare(Artifact a1, Artifact a2) {
            return a1.getName().compareTo(a2.getName());
        }
    }

    public static class sortDate implements Comparator<Artifact> {
        public int compare(Artifact a1, Artifact a2) {
            DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
            Date d_1 = new Date();
            try {
                Date a1Date = df.parse(a1.getArrivalDate());
                d_1 = a1Date;
            } catch (ParseException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            Date d_2 = new Date();
            try {
                Date a2Date = df.parse(a2.getArrivalDate());
                d_2 = a2Date;
            } catch (ParseException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            return d_1.compareTo(d_2);
        }
    }

    // sorts the records by balance
    public static class sortPrice implements Comparator<Artifact> {
        public int compare(Artifact a1, Artifact a2) {
            // this function sorts in ascending order
            if (a1.getPrice() > a2.getPrice())
                return 1;

            if (a1.getPrice() < a2.getPrice())
                return -1;

            return 0;
        }
    }

    // sorts the records by balance
    public static class sortWeight implements Comparator<Artifact> {
        public int compare(Artifact a1, Artifact a2) {
            // this function sorts in ascending order
            if (a1.getWeight() > a2.getWeight())
                return 1;

            if (a1.getWeight() < a2.getWeight())
                return -1;

            return 0;
        }
    }

    public static ArrayList<Artifact> passalongArtifacts(String filename, String keyword) {
        return ADController.retrieveArtifacts(filename, keyword);
    }
}
