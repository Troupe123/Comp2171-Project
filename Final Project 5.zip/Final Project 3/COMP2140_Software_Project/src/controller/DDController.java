package controller;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;
import entities.*;

public class DDController {
    public DDController() {
    }

    public static void AddDonor(String name, int ID, String contact, String ArtifactsDonated, int numArtifacts)
            throws IOException {
        String text;

        File file = new File("donor_list.txt");
        FileWriter fileWriter = new FileWriter(file, file.exists());
        BufferedWriter output = new BufferedWriter(fileWriter);

        String[] names = name.split(" ");
        String[] artifacts = ArtifactsDonated.split(",");
        text = names[0] + "_" + names[1] + " " + ID + " " + contact + " "
                + Arrays.toString(artifacts).replaceAll(" ", "") + " "
                + numArtifacts;

        output.write(text);

        // adding new line for next record to be appended:
        if (file.exists())
            output.newLine();

        output.close();
        fileWriter.close();

        if (file.exists())
            System.out.println("Text has been appended to the file: donor_list.txt");
        else
            System.out.println("Text has been written to a new file: donor_list.txt");
    }

    public static void remove_donor(ArrayList<Donor> dlist, String id) {
        String text_;
        for (int i = 0; i < dlist.size(); i++) {
            if (dlist.get(i).getID() == Integer.parseInt(id)) {
                System.out.println("The Student has been removed");
                dlist.remove(i);
                try {
                    File file = new File("donor_list.txt");
                    file.delete();// deletes the existing file
                    File file_ = new File("donor_list.txt"); // re creates it to be filled with the updates
                                                             // information
                    FileWriter fileWriter = new FileWriter(file, file_.exists());
                    BufferedWriter output = new BufferedWriter(fileWriter);

                    for (Donor d_ : dlist) {
                        text_ = d_.getName() + " " + d_.getID() + " " + d_.getContact() + " " + d_.getArtifactsDonated()
                                + " " + d_.getNumArtifacts();
                        output.write(text_); // each record is written to the file
                        if (file_.exists())
                            output.newLine();
                    }
                    output.close();
                    fileWriter.close();
                } catch (NumberFormatException nfe) {
                    System.out.println("Incorrect input format. Please to enter a number.");
                } catch (IOException ioe) {
                }
            }

        }

    }

    public static ArrayList<Donor> load_donor_details(String dfile) {
        Scanner pscan = null;
        ArrayList<Donor> dlist = new ArrayList<Donor>();
        try {
            // takes a file name as paramter and reads information from it
            pscan = new Scanner(new File(dfile));
            while (pscan.hasNext()) {
                String[] nextLine = pscan.nextLine().split(" ");
                String name = nextLine[0];
                int ID = Integer.parseInt(nextLine[1]);
                String contact = nextLine[2];
                String donated = nextLine[3];
                int numArtifacts = Integer.parseInt(nextLine[4]);
                dlist.add(new Donor(name, ID, contact, donated, numArtifacts));
            }
            pscan.close();
        } catch (IOException e) {
        }
        return dlist;
    }

}
