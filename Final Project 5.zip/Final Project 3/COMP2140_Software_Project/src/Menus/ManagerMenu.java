
/**
 * ADMIN MENU
 * @author Jahleel Troupe, Ryan Muir, Nathan Gordon, Vishane Stubbs
 */
package Menus;

import javax.swing.*;

import Menus_Facade.*;

import java.awt.event.*;

public class ManagerMenu extends JFrame {

   private boolean flag;

   public ManagerMenu(boolean manager_flag) {
      // JFrame frame = new JFrame();
      this.flag = manager_flag;

      JMenuBar menuBar = new JMenuBar(); // create menu bar
      JMenu menu = new JMenu("Welcome to the Managers' Menu"); // create menu

      JMenuItem add = new JMenuItem("Add an Entry Employee");
      menu.add(add);

      JMenuItem Add_A = new JMenuItem("Add an Artifact");
      menu.add(Add_A);

      JMenuItem Add_D = new JMenuItem("Add Donor");
      menu.add(Add_D);

      JMenuItem Search = new JMenuItem("Search Artifacts");
      menu.add(Search);

      JMenuItem Delete_A = new JMenuItem("Delete Artifacts");
      menu.add(Delete_A);

      JMenuItem Delete_D = new JMenuItem("Delete Donors");
      menu.add(Delete_D);

      JMenuItem view = new JMenuItem("View Museum Artifact List");
      menu.add(view);

      JMenuItem view_donor = new JMenuItem("View Donor Contact List");
      menu.add(view_donor);

      JMenuItem logout = new JMenuItem("LOGOUT");
      menu.add(logout);

      menuBar.add(menu);
      setJMenuBar(menuBar);

      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      setSize(400, 400);
      setVisible(true);

      view.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            setVisible(false);
            Facade.ViewArtifactCatalogue(flag);
         }
      });

      view_donor.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            setVisible(false);
            Facade.ViewContactList(flag);
         }
      });

      add.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            setVisible(false);
            Facade.AddEmployee(flag);
         }
      });

      logout.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            setVisible(false);
            Facade.LOGOUT();

         }
      });

      Add_A.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            setVisible(false);
            Facade.AddArtifact(flag);
         }
      });

      Search.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            setVisible(false);
            Facade.SearchforArtifacts(flag);

         }
      });

      Add_D.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            setVisible(false);
            Facade.AddDonor(flag);

         }
      });

      Delete_A.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            setVisible(false);
            Facade.DeleteArtifact(flag);
         }
      });

      Delete_D.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            setVisible(false);
            Facade.DeleteDonor(flag);

         }
      });

   }
}