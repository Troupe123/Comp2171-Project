package Security;

import java.awt.*;
import javax.swing.*;

import MAIN_GUI.*;
import controller.EmployeeController;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * EMPLOYEE LOGIN
 * 
 * @author Nathan Gordon,Jahleel Troupe, Ryan Muir, Vishane Stubbs
 */

public class EmployeeLogin extends JFrame {
    private JPanel dpanel = new JPanel(new GridLayout(3, 1));
    private JPanel bpanel = new JPanel();
    private JButton login;
    private JButton back;

    private JTextField ID = new JTextField(15);
    private JPasswordField pwd = new JPasswordField(15);

    // "global manager_flag" variable:
    public boolean manager_flag = false;

    public EmployeeLogin() {
        setLocationRelativeTo(null);
        setTitle("Museum Employee Login");
        dpanel.add(new JLabel("Employee ID: "));
        dpanel.add(ID);

        dpanel.add(new JLabel("Password: "));
        dpanel.add(pwd);

        // action buttons:
        back = new JButton("<--");
        login = new JButton("Login");

        // adding buttons to panel:
        back.setOpaque(true);
        back.setContentAreaFilled(true);
        back.setBorderPainted(false);
        back.setFocusPainted(false);
        back.setBackground(Color.darkGray); // for the background
        back.setForeground(Color.white); // for the text

        login.setOpaque(true);
        login.setContentAreaFilled(true);
        login.setBorderPainted(false);
        login.setFocusPainted(false);
        login.setBackground(Color.darkGray); // for the background
        login.setForeground(Color.white); // for the text

        bpanel.setLayout(new FlowLayout());
        bpanel.add(back);
        bpanel.add(login);

        // button listeners:
        back.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new InventoryManagement();
                setVisible(false);
            }
        });

        login.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // handles case where username and password field is empty. will give an error
                // message to user:
                if ((!ID.getText().isEmpty()) && pwd.getPassword().length > 0) {
                    setVisible(false);
                    EmployeeController.checkLogin(ID.getText(), new String(pwd.getPassword()), manager_flag);
                }
                // error message for null input:
                else
                    JOptionPane.showMessageDialog(null, "Null input detected. Please enter valid characters.");
            }
        });

        // adding panels to frame:
        add(dpanel, BorderLayout.NORTH);
        add(bpanel, BorderLayout.SOUTH);
        pack();
        setVisible(true);
    }

}