package functions;

import java.awt.*;
import javax.swing.*;

import java.util.ArrayList;
import java.io.IOException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.table.DefaultTableModel;
import controller.*;
import entities.Artifact;
import Menus.*;

/**
 * DELETE
 * 
 * @author Jahleel Troupe, Ryan Muir, Nathan Gordon
 */

public class DeleteArtifact extends JFrame {
    private boolean flag_;
    private JPanel dispanel = new JPanel();
    private JPanel cmdPanel = new JPanel();

    private JButton remove = new JButton("Remove");
    private JButton close = new JButton("Close");

    private JTextField id = new JTextField(15);

    private JTable table;

    private DefaultTableModel model;

    static ArrayList<Artifact> alist;

    private JScrollPane scrollPane;

    public DeleteArtifact(boolean flag) {
        this.flag_ = flag;
        setTitle("Remove an Artifact from the Catalogue");
        setLocationRelativeTo(null);
        dispanel.setSize(950, 300);

        dispanel.add(new JLabel("Artifact ID [ID #]"));
        dispanel.add(id);

        alist = ArtifactController.loadArtifacts("artifact_catalogue.txt");
        String[] columnNames = { "Name",
                "ID #",
                "Brief Description",
                "Status",
                "Weight",
                "Price",
                "Date of Arrival" };
        model = new DefaultTableModel(columnNames, 0);// default table
        table = new JTable(model);// takes in the default table
        showTable(alist);

        // sets the size
        table.setPreferredScrollableViewportSize(new Dimension(900, alist.size() * 15 + 50));

        table.setFillsViewportHeight(true);

        scrollPane = new JScrollPane(table);

        add(scrollPane);

        table.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);

        remove.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                // check for selected row first
                if (table.getSelectedRow() != -1) {
                    // remove selected row from the model
                    model.removeRow(table.getSelectedRow());
                    JOptionPane.showMessageDialog(null, "Selected record deleted successfully!");
                    try {
                        ArtifactController.remove(alist, id.getText());
                    } catch (IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                    setVisible(false);
                    if (flag_ == false) {
                        new EmployeeMenu(flag_);
                    } else {
                        new ManagerMenu(flag_);
                    }

                }
            }
        });

        close.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                if (flag_ == false)
                    new EmployeeMenu(flag_);

                else
                    new ManagerMenu(flag_);

            }
        });

        remove.setOpaque(true);
        remove.setContentAreaFilled(true);
        remove.setBorderPainted(false);
        remove.setFocusPainted(false);
        remove.setBackground(Color.darkGray); // for the background
        remove.setForeground(Color.white); // for the text

        close.setOpaque(true);
        close.setContentAreaFilled(true);
        close.setBorderPainted(false);
        close.setFocusPainted(false);
        close.setBackground(Color.darkGray); // for the background
        close.setForeground(Color.white); // for the text

        // adding components to panels:
        dispanel.add(new JScrollPane(table));
        cmdPanel.add(remove);
        cmdPanel.add(close);

        add(dispanel, BorderLayout.CENTER);
        add(cmdPanel, BorderLayout.SOUTH);

        setSize(950, 300);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void showTable(ArrayList<Artifact> alist) {
        if (alist.size() > 0) {
            for (Artifact list : alist)
                addToTable(list);
        }
    }

    private void addToTable(Artifact a) {
        String[] item = { a.getName(), " " + a.getID(), " " + a.getDescription(), " " + a.getStatus(),
                " " + a.getWeight(),
                " " + a.getPrice(), " " + a.getArrivalDate() };
        model.addRow(item);

    }
}