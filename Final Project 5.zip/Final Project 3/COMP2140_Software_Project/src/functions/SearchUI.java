package functions;

import java.awt.*;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JLabel;
import javax.swing.JTextField;

import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.table.DefaultTableModel;

import Menus.EmployeeMenu;
import Menus.ManagerMenu;
import controller.ArtifactController;
import entities.Artifact;

public class SearchUI extends JFrame {
    private boolean flag_;
    public JPanel dispanel = new JPanel(new GridLayout(5, 1));
    public JPanel cmdpanel = new JPanel();

    private JTextField search = new JTextField(50);
    public JButton Close = new JButton("Close");

    // nathan added this:
    public JButton Search = new JButton("Search");

    private JTable table;
    private DefaultTableModel model;
    private ArrayList<Artifact> a_list;
    private JScrollPane scrollPane;

    public SearchUI(boolean flag) {
        this.flag_ = flag;
        setTitle("Search Panel");
        setSize(400, 300);
        setLocationRelativeTo(null);

        dispanel.add(new JLabel("Search :"));
        dispanel.add(search);

        a_list = loadArtifact("artifact_catalogue.txt");
        String[] columnNames = { "Name",
                "ID #",
                "Brief Description",
                "Status",
                "Weight",
                "Price",
                "Date of Arrival" };
        model = new DefaultTableModel(columnNames, 0);// default table
        table = new JTable(model);// takes in the default table
        // showTable(a_list);

        // sets the size
        table.setPreferredScrollableViewportSize(new Dimension(900, a_list.size() * 15 + 50));

        table.setFillsViewportHeight(true);

        scrollPane = new JScrollPane(table);

        add(scrollPane);

        // adding functionality to the buttons
        Close.addActionListener(new CloseButtonListener());
        Search.addActionListener(new SearchButtonListener());

        Close.setOpaque(true);
        Close.setContentAreaFilled(true);
        Close.setBorderPainted(false);
        Close.setFocusPainted(false);
        Close.setBackground(Color.darkGray); // for the background
        Close.setForeground(Color.white); // for the text

        // nathan added this:
        cmdpanel.add(Search);

        cmdpanel.add(Close);

        add(dispanel, BorderLayout.NORTH);
        add(cmdpanel, BorderLayout.SOUTH);
        pack();
        setVisible(true);
    }

    private ArrayList<Artifact> loadArtifact(String sfile) {
        return ArtifactController.passalongArtifacts(sfile, search.getText());
    }

    public void addArtifact(Artifact a) {
        a_list.add(a);
        addToTable(a);
    }

    private void showTable(ArrayList<Artifact> slist) {
        if (slist.size() > 0) {
            for (Artifact list : slist)
                addToTable(list);
        }
    }

    private void addToTable(Artifact a) {
        String[] item = { a.getName(), "" + a.getID(), "" + a.getDescription(), "" + a.getStatus(), "" + a.getWeight(),
                "" + a.getPrice(), "" + a.getArrivalDate() };
        model.addRow(item);
    }

    // nathan added this:
    private class SearchButtonListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            a_list = loadArtifact("artifact_catalogue.txt");

            // System.out.println(a_list);

            // Clear existing data in the table
            model.setRowCount(0);

            // Add new data to the table
            showTable(a_list);

            // sets the size
            table.setPreferredScrollableViewportSize(new Dimension(900, a_list.size() * 15 + 50));

            table.setFillsViewportHeight(true);

            // Update the existing JScrollPane
            scrollPane.setViewportView(table);
        }
    }

    private class CloseButtonListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            setVisible(false);

            if (flag_ == false)
                new EmployeeMenu(flag_);
            else
                new ManagerMenu(flag_);
        }
    }
}
