package functions;

import java.awt.*;
import javax.swing.*;

import Menus.ManagerMenu;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import controller.*;

/**
 * ADD EMPLOYEE DETAILS
 * 
 * @author Nathan Gordon, Vishane Stubbs, Ryan Muir
 */

public class AddEmployee extends JFrame {

    private JPanel dispanel = new JPanel();
    private JPanel gendPanel = new JPanel();
    private JPanel companel = new JPanel();
    private JButton cancel;
    private JButton save;

    private JTextField name = new JTextField(15);
    private JTextField ID = new JTextField(15);
    private JTextField role = new JTextField(15);
    private JPasswordField pwd = new JPasswordField(15);
    private JCheckBox male = new JCheckBox();
    private JCheckBox female = new JCheckBox();
    private JCheckBox other = new JCheckBox();
    private boolean flag_;

    public AddEmployee(boolean flag) {
        this.flag_ = flag;
        setTitle("Create an employee");
        // dispanel.setLayout(new BoxLayout(dispanel, BoxLayout.Y_AXIS));
        dispanel.setLayout(new GridLayout(6, 5));
        setSize(400, 400);
        setLocationRelativeTo(null);

        // start of display panel:
        dispanel.add(new JLabel("Enter your name: "));
        dispanel.add(name);

        dispanel.add(new JLabel("Enter your ID#: "));
        dispanel.add(ID);

        dispanel.add(new JLabel("Enter your role [Manager/Entry Level Employee]: "));
        dispanel.add(role);

        // start of gender panel
        gendPanel.add(new JLabel("Select your gender: |"));
        gendPanel.add(new JLabel("Male: "));
        gendPanel.add(male);
        gendPanel.add(new JLabel("Female: "));
        gendPanel.add(female);
        gendPanel.add(new JLabel("Other: "));
        gendPanel.add(other);

        dispanel.add(gendPanel);

        dispanel.add(new JLabel("Create a secure password: "));
        dispanel.add(pwd);

        // action buttons:
        save = new JButton("save");
        cancel = new JButton("cancel");

        save.setOpaque(true);
        save.setContentAreaFilled(true);
        save.setBorderPainted(false);
        save.setFocusPainted(false);
        save.setBackground(Color.darkGray); // for the background
        save.setForeground(Color.white); // for the text

        cancel.setOpaque(true);
        cancel.setContentAreaFilled(true);
        cancel.setBorderPainted(false);
        cancel.setFocusPainted(false);
        cancel.setBackground(Color.darkGray); // for the background
        cancel.setForeground(Color.white); // for the text

        // adding buttons to panel:
        companel.setLayout(new FlowLayout());
        // dispanel.setLayout(BorderLayout);
        companel.add(save);
        companel.add(cancel);

        // button listeners:
        save.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // handles case where username and password field is empty. will give an error
                // message to user:
                String gender = "";
                if (male.isSelected() || female.isSelected() || other.isSelected()) {
                    try {

                        if (male.isSelected())
                            gender = "M";

                        if (female.isSelected())
                            gender = "F";

                        if (other.isSelected())
                            gender = "O";
                        setVisible(false);
                        EmployeeController.storeEmployee(name.getText(), role.getText(), gender,
                                Integer.parseInt(ID.getText()), new String(pwd.getPassword()));

                    } catch (NumberFormatException nfe) {
                        JOptionPane.showMessageDialog(null, "Null input detected. Please enter valid characters.");
                    }

                    new ManagerMenu(flag_);
                }

            }
        });

        cancel.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                new ManagerMenu(flag_);
            }
        });

        // adding panels to frame:
        add(dispanel, BorderLayout.NORTH);
        add(companel, BorderLayout.SOUTH);
        pack();
        setVisible(true);

    }
}
