package functions;

import java.awt.*;
import javax.swing.*;

import java.util.ArrayList;
import java.io.IOException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.table.DefaultTableModel;

import Menus.EmployeeMenu;
import Menus.ManagerMenu;
import controller.DonorController;
import entities.Donor;

public class DeleteDonor extends JFrame {
    private boolean flag_;
    private JPanel dispanel = new JPanel();
    private JPanel cmdPanel = new JPanel();

    private JButton remove = new JButton("Remove");
    private JButton close = new JButton("Close");

    private JTextField id = new JTextField(15);

    private JTable table;

    private DefaultTableModel model;

    static ArrayList<Donor> dlist;

    private JScrollPane scrollPane;

    public DeleteDonor(boolean flag) {
        this.flag_ = flag;
        setTitle("Remove a Donor from the Contact List");
        dispanel.setSize(950, 300);

        dispanel.add(new JLabel("Donor ID [ID #]"));
        dispanel.add(id);

        dlist = DonorController.loadDonors("donor_list.txt");
        String[] columnNames = { "Name",
                "Donor ID",
                "Contact Information",
                "Artifacts Donated",
                "Nummber of Artifacts Donated" };
        model = new DefaultTableModel(columnNames, 0);// default table
        table = new JTable(model);// takes in the default table
        showTable(dlist);

        // sets the size
        table.setPreferredScrollableViewportSize(new Dimension(900, dlist.size() * 15 + 50));

        table.setFillsViewportHeight(true);

        scrollPane = new JScrollPane(table);

        add(scrollPane);

        table.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);

        remove.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                // check for selected row first
                if (table.getSelectedRow() != -1) {
                    // remove selected row from the model
                    model.removeRow(table.getSelectedRow());
                    JOptionPane.showMessageDialog(null, "Selected row deleted successfully");
                    try {
                        DonorController.remove(dlist, id.getText());
                    } catch (IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                    setVisible(false);
                }
            }
        });

        close.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                if (flag_ == false) {
                    new EmployeeMenu(flag_);
                } else {
                    new ManagerMenu(flag_);
                }

            }
        });

        remove.setOpaque(true);
        remove.setContentAreaFilled(true);
        remove.setBorderPainted(false);
        remove.setFocusPainted(false);
        remove.setBackground(Color.darkGray); // for the background
        remove.setForeground(Color.white); // for the text

        close.setOpaque(true);
        close.setContentAreaFilled(true);
        close.setBorderPainted(false);
        close.setFocusPainted(false);
        close.setBackground(Color.darkGray); // for the background
        close.setForeground(Color.white); // for the text

        // adding components to panels:
        dispanel.add(new JScrollPane(table));
        cmdPanel.add(remove);
        cmdPanel.add(close);

        add(dispanel, BorderLayout.CENTER);
        add(cmdPanel, BorderLayout.SOUTH);

        setSize(950, 300);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void showTable(ArrayList<Donor> dlist) {
        if (dlist.size() > 0) {
            for (Donor list : dlist)
                addToTable(list);
        }
    }

    private void addToTable(Donor d) {
        String[] item = { d.getName(), " " + d.getID(), " " + d.getContact(), " " + d.getArtifactsDonated(),
                " " + d.getNumArtifacts() };
        model.addRow(item);
    }

}
