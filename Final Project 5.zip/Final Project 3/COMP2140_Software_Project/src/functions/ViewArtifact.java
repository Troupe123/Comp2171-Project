package functions;

import java.awt.*;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTable;
// import javax.swing.JTextField;
import java.util.ArrayList;
// import java.util.Arrays;

import javax.swing.JButton;
import javax.swing.JCheckBox;

import java.util.Collections;
import javax.swing.JScrollPane;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.table.DefaultTableModel;

import Menus.EmployeeMenu;
import Menus.ManagerMenu;
import controller.ArtifactController;
import entities.Artifact;

/**
 * VIEW
 * 
 * @author Jahleel Troupe, Ryan Muir, Nathan Gordon, Vishane Stubbs
 */

public class ViewArtifact extends JFrame {
    private boolean flag;
    public JPanel dispanel = new JPanel(new GridLayout(5, 1));
    public JPanel cmdpanel = new JPanel();
    public JPanel filterpanel = new JPanel(new GridLayout(0, 1));

    public JButton sort_name = new JButton("Sort by Name");
    public JButton sort_price = new JButton("Sort by Price");
    public JButton sort_weight = new JButton("Sort by Weight");
    public JButton sort_date = new JButton("Sort by the Date of Arrival");
    public JButton Close = new JButton("Close");
    public JButton Reset = new JButton("Reset");

    private JTable table;
    private DefaultTableModel model;
    static ArrayList<Artifact> alist;
    static ArrayList<Artifact> alist2;
    private JScrollPane scrollPane;

    // private ArrayList<Artifact> filteredList;
    static JCheckBox range0to20 = new JCheckBox("0 - 20 kg");
    static JCheckBox range20to100 = new JCheckBox("20 - 100 kg");
    static JCheckBox rangeabove100 = new JCheckBox(">100 kg");

    public JCheckBox range1 = new JCheckBox("0 - 100000 ");
    public JCheckBox range2 = new JCheckBox("100000 - 1000000 ");
    public JCheckBox range3 = new JCheckBox(">1000000");

    public ViewArtifact(boolean flag) {
        this.flag = flag;
        setTitle("Artifact View");
        setSize(400, 300);
        setLocationRelativeTo(null);

        alist = ArtifactController.loadArtifacts("artifact_catalogue.txt");
        String[] columnNames = { "Name",
                "ID #",
                "Brief Description",
                "Status",
                "Weight",
                "Price",
                "Date of Arrival" };
        alist2 = alist;
        model = new DefaultTableModel(columnNames, 0);// default table
        table = new JTable(model);// takes in the default table
        showTable(alist);

        // sets the size
        table.setPreferredScrollableViewportSize(new Dimension(900, alist.size() * 15 + 50));

        table.setFillsViewportHeight(true);

        scrollPane = new JScrollPane(table);

        add(scrollPane);
        // FILTERS TO GO HERE:
        filterpanel.add(new JLabel("FILTER BY WEIGHT|"));
        filterpanel.add(range0to20);
        filterpanel.add(range20to100);
        filterpanel.add(rangeabove100);

        range0to20.addActionListener(new FilterListener1());
        range20to100.addActionListener(new FilterListener2());
        rangeabove100.addActionListener(new FilterListener3());

        filterpanel.add(new JLabel("FILTER BY PRICE|"));
        filterpanel.add(range1);
        filterpanel.add(range2);
        filterpanel.add(range3);

        range1.addActionListener(new PriceListener1());
        range2.addActionListener(new PriceListener2());
        range3.addActionListener(new PriceListener3());

        add(filterpanel, BorderLayout.EAST);

        // adding functionality to the buttons
        sort_name.addActionListener(new SortNameListener());
        sort_price.addActionListener(new Sortbyprice());
        sort_weight.addActionListener(new Sortbyweight());
        sort_date.addActionListener(new SortDateListener());
        Close.addActionListener(new CloseButtonListener());
        Reset.addActionListener(new ResetListener());

        sort_name.setOpaque(true);
        sort_name.setContentAreaFilled(true);
        sort_name.setBorderPainted(false);
        sort_name.setFocusPainted(false);
        sort_name.setBackground(Color.darkGray); // for the background
        sort_name.setForeground(Color.white); // for the text

        sort_price.setOpaque(true);
        sort_price.setContentAreaFilled(true);
        sort_price.setBorderPainted(false);
        sort_price.setFocusPainted(false);
        sort_price.setBackground(Color.darkGray); // for the background
        sort_price.setForeground(Color.white); // for the text

        Close.setOpaque(true);
        Close.setContentAreaFilled(true);
        Close.setBorderPainted(false);
        Close.setFocusPainted(false);
        Close.setBackground(Color.darkGray); // for the background
        Close.setForeground(Color.white); // for the text

        Reset.setOpaque(true);
        Reset.setContentAreaFilled(true);
        Reset.setBorderPainted(false);
        Reset.setFocusPainted(false);
        Reset.setBackground(Color.darkGray); // for the background
        Reset.setForeground(Color.white); // for the text

        // addition of buttons to command panel
        cmdpanel.add(sort_name);
        cmdpanel.add(sort_price);
        cmdpanel.add(sort_weight);
        cmdpanel.add(sort_date);
        cmdpanel.add(Close);
        cmdpanel.add(Reset);

        add(dispanel, BorderLayout.NORTH);
        add(cmdpanel, BorderLayout.SOUTH);
        pack();
        setVisible(true);
    }

    private void showTable(ArrayList<Artifact> alist) {
        if (alist.size() > 0) {
            for (Artifact list : alist)
                addToTable(list);
        }
    }

    private void addToTable(Artifact a) {
        String[] item = { a.getName(), "" + a.getID(), "" + a.getDescription(), "" + a.getStatus(), "" + a.getWeight(),
                "" + a.getPrice(), "" + a.getArrivalDate() };
        model.addRow(item);

    }

    // listener for balance sort button
    private class Sortbyprice implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            Collections.sort(alist, new ArtifactController.sortPrice());
            model.setRowCount(0);
            showTable(alist);
        }
    }

    // listener for name sort button
    private class SortNameListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            Collections.sort(alist, new ArtifactController.nameCompare());
            model.setRowCount(0);
            showTable(alist);
        }
    }

    private class SortDateListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            Collections.sort(alist, new ArtifactController.sortDate());
            model.setRowCount(0);
            showTable(alist);
        }
    }

    private class Sortbyweight implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            Collections.sort(alist, new ArtifactController.sortWeight());
            model.setRowCount(0);
            showTable(alist);
        }
    }

    // sorts the names in the table by comparing individual letters

    private class CloseButtonListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            setVisible(false);
            if (flag == false)
                new EmployeeMenu(flag);
            else
                new ManagerMenu(flag);
        }
    }

    private class FilterListener1 implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            if (range0to20.isSelected()) {
                model.setRowCount(0);
                showTable(ArtifactController.Filter1(alist));
                alist = ArtifactController.Filter1(alist);
            } else {
                model.setRowCount(0);
                showTable(alist2);
            }

        }
    }

    private class FilterListener2 implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            // Create a new list to store the filtered artifacts
            if (range20to100.isSelected()) {
                model.setRowCount(0);
                showTable(ArtifactController.Filter2(alist));
                alist = ArtifactController.Filter2(alist);
            } else {
                model.setRowCount(0);
                showTable(alist2);
            }
        }
    }

    private class FilterListener3 implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            if (rangeabove100.isSelected()) {
                model.setRowCount(0);
                showTable(ArtifactController.Filter3(alist));
                alist = ArtifactController.Filter3(alist);
            } else {
                model.setRowCount(0);
                showTable(alist2);
            }
        }
    }

    private class PriceListener1 implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            if (range1.isSelected()) {
                model.setRowCount(0);
                showTable(ArtifactController.Price1(alist));
                alist = ArtifactController.Price1(alist);
            } else {
                model.setRowCount(0);
                showTable(alist2);
            }

        }
    }

    private class PriceListener2 implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            if (range2.isSelected()) {
                // Iterate through the original list and filter based on checkbox selections
                model.setRowCount(0);
                showTable(ArtifactController.Price2(alist));
                alist = ArtifactController.Price2(alist);
            } else {
                model.setRowCount(0);
                showTable(alist2);
            }
        }
    }

    private class PriceListener3 implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            if (range3.isSelected()) {
                model.setRowCount(0);
                showTable(ArtifactController.Price3(alist));
                alist = ArtifactController.Price3(alist);
            } else {
                model.setRowCount(0);
                showTable(alist2);
            }
        }
    }

    private class ResetListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            alist = alist2;

            model.setRowCount(0);
            showTable(alist);
        }

    }
}
