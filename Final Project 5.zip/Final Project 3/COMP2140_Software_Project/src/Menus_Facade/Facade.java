package Menus_Facade;

import Security.EmployeeLogin;
import functions.*;

public class Facade {
    public Facade() {
    }

    public static void AddArtifact(boolean flag) {
        new AddArtifactUI(flag);
    }

    public static void AddDonor(boolean flag) {
        new AddDonorUI(flag);
    }

    public static void AddEmployee(boolean flag) {
        new AddEmployee(flag);
    }

    public static void DeleteArtifact(boolean flag) {
        new DeleteArtifact(flag);
    }

    public static void DeleteDonor(boolean flag) {
        new DeleteDonor(flag);
    }

    public static void SearchforArtifacts(boolean flag) {
        new SearchUI(flag);

    }

    public static void ViewArtifactCatalogue(boolean flag) {
        new ViewArtifact(flag);
    }

    public static void ViewContactList(boolean flag) {
        new ViewContactList(flag);
    }

    public static void LOGOUT() {
        new EmployeeLogin();
    }
}